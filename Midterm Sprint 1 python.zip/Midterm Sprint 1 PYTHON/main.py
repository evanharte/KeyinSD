# This program is a cool, work-related program for employees of the NL Chocolate Company.
# Written by: Brady Goodyear, Lauren Wilson, and Evan Harte (group 14).
# Date written: June 17-28, 2023


# Libraries:
import datetime as dt
import FormatValues as FV

# Constants:
CURR_DATE = dt.datetime.now()
DAILY_RATE = 85.00
KILO_RATE = .17
DAY_RENT_RATE = 65.00
HST_RATE = .15


# Functions:


def validate_date(date_str):
    # Functions to validate date
    try:
        dt.datetime.strptime(date_str, "%d/%m/%Y")
        return True
    except:
        return False


def num_days(start_date, end_date):
    # Function to calculate number of days between dates
    start = dt.datetime.strptime(start_date, "%d/%m/%Y")
    end = dt.datetime.strptime(end_date, "%d/%m/%Y")
    return (end - start).days


def EmpTravelClaim():
    while True:

        # User Inputs and Validations
        while True:
            empNumber = input("Enter employee number (99999): ")

            if empNumber == "":
                print("Error - employee number cannot be blank")
            elif len(empNumber) != 5:
                print("Error - employee number must be 5 digits.")
            elif not empNumber.isdigit():
                print("Error - Employee number must be 5 digits.")
            else:
                break
       # if empNumber == "00000":
       #     break

        while True:
            firstName = input("Enter first name: ").title()

            if firstName == "":
                print("Error - first name cannot be blank.")
            elif not firstName.isalpha():
                print("Error - first name contains invalid characters.")
            else:
                break

        while True:
            lastName = input("Enter last name: ").title()

            if lastName == "":
                print("Error - last name cannot be blank.")
            elif not lastName.isalpha():
                print("Error - last name contains invalid characters.")
            else:
                break

        while True:
            locationTrip = input("Enter the location: ").title()

            if locationTrip == "":
                print("Error - location cannot be empty.")
            else:
                break

        while True:
            start_date = input("Enter the start date (DD/MM/YYYY): ")
            if not validate_date(start_date):
                print("Error - invalid start date format.")
            else:
                break

        while True:
            end_date = input("Enter the end date (DD/MM/YYYY): ")
            if not validate_date(end_date):
                print("Error - invalid end date format.")
            elif start_date > end_date:
                print("Error - end date must be after start date.")
            else:
                days = num_days(start_date, end_date)
                if days > 7:
                    print("Error - trip duration cannot exceed 7 days.")
                else:
                    break

        while True:
            carType = input("Did the employee use their own car (O) or a rented car (R)? ").upper()

            if carType in ['O', 'R']:
                break
            else:
                print("Error - Please enter 'O' if the employee used their own car or 'R' if a car was rented.")

        if carType == 'O':
            while True:
                try:
                    kilometers = int(input("Enter the number of kilometers traveled: "))
                    if kilometers <= 2000:
                        break
                    else:
                        print("Error - The number of kilometers cannot exceed 2000.")
                except ValueError:
                    print("Error - Invalid input. Please enter an integer.")
        else:
            kilometers = 0

        while True:
            claimType = input("Enter the claim type (S/E): ").upper()

            if claimType == "":
                print("Error - claim type cannot be empty.")
            elif claimType != "S" and claimType != "E":
                print("Error - claim type must be S/E.")
            else:
                break

        # Program Calculations

        bonus = 0
        start_datetime = dt.datetime.strptime(start_date, "%d/%m/%Y")
        end_datetime = dt.datetime.strptime(end_date, "%d/%m/%Y")

        perDiemAmt = days * DAILY_RATE

        if carType == "O":
            mileageAmt = kilometers * KILO_RATE
        else:
            mileageAmt = days * DAY_RENT_RATE

        # Bonus Calculations

        if days > 3:
            bonus += 100.00

        if kilometers > 1000 and carType == "O":
            bonus += (kilometers - 1000) * .04

        if claimType == "E":
            bonus += days * 45.00

        if start_datetime.month == 12 and 15 <= start_datetime.day <= 22:
            bonus += days * 50.00

        claimAmt = perDiemAmt + mileageAmt + bonus

        hstAmt = claimAmt * HST_RATE

        totalClaimAmt = claimAmt + hstAmt

        # Formatting

        nameDsp = firstName + " " + lastName

        if claimType == "E":
            claimTypeDsp = "EXECUTIVE"
        else:
            claimTypeDsp = "STANDARD"

        print()
        print("=========================================")
        print("     EMPLOYEE EXPENSE CLAIM RECEIPT      ")
        print("         NL CHOCOLATE COMPANY            ")
        print("=========================================")
        print()
        print("Employee Name and Number:")
        print(f"       {nameDsp:>20s}, {empNumber:<5}")
        print()
        print(f"Location:                {locationTrip:>16s}")
        print(f"Trip Duration:                     {days:<1d} days")
        print(f"Claim Type:                     {claimTypeDsp:>9s}")
        print("                            -------------")
        print(f"Start Date:                    {start_date:<9s}")
        print(f"End Date:                      {end_date:<9s}")
        print("=========================================")
        print(f"Per Diem Amount:               {FV.FDollar2(perDiemAmt):>10s}")
        if carType == "O":
            print(f"Mileage Amount:                {FV.FDollar2(mileageAmt):>10s}")
            print(f"Kilometers:                     {FV.FKiloKM(kilometers):>5s} ")
        print("                            -------------")
        print(f"Bonus:                         {FV.FDollar2(bonus):>10s}")
        print(f"Claim Amount:                  {FV.FDollar2(claimAmt):>10s}")
        print(f"HST Amount:                    {FV.FDollar2(hstAmt):>10s}")
        print()
        print(f"Total Claim Amount:            {FV.FDollar2(totalClaimAmt):>10s}")
        print("=========================================")
        print("                THANK YOU                 ")
        print()
        break

    print()
    print("--- Thank you for using our employee travel expense claim! ---")


def FunInterviewQuestion():
    # Repeat for the numbers 1 - 100
    for i in range(1, 101):
        # Multiples of 40 are divisible by both 5 and 8, so first check
        # and print 'FizzBizz' if this number is divisible by 40
        if i % 40 == 0:
            print("FizzBizz")
        # Print 'Fizz' if this number is divisible by 5
        elif i % 5 == 0:
            print("Fizz")
        # Print 'Bizz' if this number is divisible by 8
        elif i % 8 == 0:
            print("Bizz")
        else:
            print(i)


def CoolStuffStringsDates():
    print()
    while True:
        FirstName = input("Enter employee first name: ").title()
        if FirstName == "":
            print("Error - First name cannot be blank.")
        else:
            break

    while True:
        LastName = input("Enter employee last name: ").title()
        if LastName == "":
            print("Error - Last name cannot be blank.")
        else:
            break

    while True:
        PhNum = input("Enter phone number (9999999999): ")
        if PhNum == "":
            print("Error - Phone number can't be blank.")
        elif not PhNum.isdigit:
            print("Error - Invalid input. Phone number must contain only numbers.")
        elif len(PhNum) != 10:
            print("Error - Phone number must be 10 digits (9999999999).")
        else:
            break

    while True:
        try:
            StartDate = input("Enter employee start date (YYYY-MM-DD): ")
            StartDate = dt.datetime.strptime(StartDate, "%Y-%m-%d")
        except:
            print("Error - Invalid format for start date. Enter as: YYYY-MM-DD.")
        else:
            break

    while True:
        try:
            Birthday = input("Enter employee date of birth (YYYY-MM-DD): ")
            Birthday = dt.datetime.strptime(Birthday, "%Y-%m-%d")
        except:
            print("Error - Invalid format for birthday. Enter as: YYYY-MM-DD.")
        else:
            break

    CoolStuff = CoolStuffMessage(StartDate, Birthday, FirstName, LastName, PhNum)
    print()
    print(CoolStuff)
    print()
    input("Press 'Enter' to continue ... ")


def CoolStuffMessage(EmpStartDate, EmpBirthday, FirstName, LastName, PhNum):
    # Calculates how many days employee has been with the company and how many days it's been since they were born.

    DaysWithCompany = (CURR_DATE - EmpStartDate).days
    DaysSinceBorn = (CURR_DATE - EmpBirthday).days

    Message = f"{FirstName} {LastName} (Ph#:{PhNum}) has been with this company {DaysWithCompany} day(s) and was born {DaysSinceBorn} day(s) ago!"

    return Message


def SomethingOldNew():
    # This function displays a menu from which the user can display the entries in
    #   an external journal file, or write new entries to the file.

    # Open the journal file in append+read mode
    # If the file does not exist, it will be created
    # File pointer will be at the end of the file
    # (It is important to bear in mind where the pointer will be)
    file = open("journal.txt", "a+")

    print()
    print("Welcome to the journal submenu!")
    while True:
        print("1. Add a new entry.")
        print("2. Print all entries.")
        print("3. Close the journal.")
        print()
        selection = input("Enter choice (1-3): ")
        if selection == "1":
            # "New Entry" was selected
            # Ask user for the content of the new line
            newEntry = input("Write the new entry: ")

            # Create a nicely formatted timestamp
            now = dt.datetime.now()
            timestamp = now.strftime("%b %d, %Y - %H:%M: ")

            # Write both the timestamp and the new entry to the file
            # A newline character is added to the end of the entry
            file.write(timestamp + newEntry + "\n")

            # For the sake of tidiness, print a new line
            print("")
        elif selection == "2":
            # "Print all entries" was selected
            print("All journal entries:")

            # Move the file pointer back to the start of the file
            file.seek(0)

            # Iterate over every line in the file, and print it
            for line in file:
                print(line, end="")
            # Afterward, pointer will be at the end of the file.

            # For the sake of tidiness, print a new line
            print()
        elif selection == "3":
            # "Close the journal" was selected, exit loop
            break
        else:
            print("Invalid selection.")

    # Close the journal file
    file.close()


# Menu display:
while True:

    print()
    print("  NL Chocolate Company")
    print("  Travel Claims Processing System")
    print()
    print("  1.  Enter an Employee Travel Claim.")
    print("  2.  Fun Interview Question.")
    print("  3.  Cool Stuff with Strings and Dates.")
    print("  4.  Something Old, Something New.")
    print("  5.  Quit Program.")
    print()

    # Inputs & validations:

    try:
        Choice = int(input("      Enter choice (1-5): "))
    except:
        print()
        print("Error - not a valid number. Enter a number between 1-5.")
        input("Press 'Enter' to continue ... ")
    else:
        if Choice < 1 or Choice > 5:
            print()
            print("Error - number must be between 1-5.")
            input("Press 'Enter' to continue ... ")
        elif Choice == 1:
            print()
            EmpTravelClaim()
            print()
            input("Press 'Enter' to continue ... ")
        elif Choice == 2:
            FunInterviewQuestion()
            print()
            input("Press 'Enter' to continue ... ")
        elif Choice == 3:
            CoolStuffStringsDates()
        elif Choice == 4:
            SomethingOldNew()
            print()
            input("Press 'Enter' to continue ... ")
        else:
            print()
            print("--- Thank you for using the NL Chocolate Company employee program. Bye-bye! ---")
            break
